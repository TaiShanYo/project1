create view v_student as
  select `test`.`student`.`name` AS `姓名`, `test`.`student`.`sex` AS `性别`
  from `test`.`student`
  where (`test`.`student`.`sex` = '男');

