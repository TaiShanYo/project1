create view v_studenta as
  select (year(ifnull(`y`.`AIAX0046`, `y`.`AIAX0048`)) - substr(`y`.`AIAP0007`, 1, 4)) AS `manAge`,
         (year(ifnull(`y`.`AIAX0046`, `y`.`AIAX0048`)) - substr(`y`.`AIAP0008`, 1, 4)) AS `womanAge`
  from (`test`.`ia_marriage` `y` join `test`.`gua_area` `g` on (((`g`.`parentareacode` = '331100000000') and
                                                                 (`g`.`searchareacode` =
                                                                  substr(`y`.`CIAE0001`, 1, 6)))))
  where ((`y`.`CIAE0001` like convert(concat('3311', '%') using utf8)) and (`y`.`AIAP0023` = '10'));

